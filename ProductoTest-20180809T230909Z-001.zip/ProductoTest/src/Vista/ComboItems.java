/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Vista;

import Utilidades.DBInstance;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.management.Query;

/**
 *
 * @author Nigger
 */
public class ComboItems {
/*public Connection getConnection(){
        Connection con = null;
        try {
            con = DriverManager.getConnection("jdbc:mysql://localhost/productos", "root","");
        } catch (SQLException ex) {
            Logger.getLogger(Query.class.getName()).log(Level.SEVERE, null, ex);
        }
        return con;
    }
        
   public HashMap<String,Integer> populateCombo(){
      HashMap<String, Integer> map = new HashMap<String, Integer>();
      Connection con = getConnection();
      Statement st;
      ResultSet rs;
      
       try {
           st = con.createStatement();
           rs = st.executeQuery("SELECT idCategoria, nombreCategoria FROM Categoria");
           Categoria cmi;
           
           while(rs.next()){
               cmi = new Categoria(rs.getInt(1), rs.getString(2));
               map.put(cmi.getNombreCategoria(), cmi.getIdCategoria());
           }
           
       } catch (SQLException ex) {
           Logger.getLogger(ComboItems.class.getName()).log(Level.SEVERE, null, ex);    
        }
      
       return map;
   }*/
}
