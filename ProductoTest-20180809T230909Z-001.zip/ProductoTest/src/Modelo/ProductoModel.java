/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import Utilidades.DBInstance;
import static Utilidades.DBInstance.closeConnection;
import static Utilidades.DBInstance.stateConnection;
import Vista.Producto;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
/**
 *
 * @author Nigger
 */
public class ProductoModel {
    protected Connection getConnection(){
        return DBInstance.getInstanceConnection();
    }
        public Object [][] getProducto(){
        int posId = 0;
        
        try {
            //ps position
            PreparedStatement pstm = getConnection().prepareStatement("SELECT count(1) as total FROM producto");
            ResultSet res = pstm.executeQuery();
            
            res.next();
            posId = res.getInt("total");
            
        } catch (SQLException e){
            System.out.println("Error: "+e);
        }
        
        Object[][] data = new String[posId][5];
        
        try{
            PreparedStatement pstm = getConnection().prepareStatement("SELECT idproducto, nombrecategoria, nombre, unidadcaja, precio FROM producto\n" +
"INNER JOIN categoria on producto.idCategoria = categoria.idCategoria ORDER BY idProducto");
            ResultSet res = pstm.executeQuery();
            
            int increment = 0;
            
            while(res.next()){
                String idProducto = res.getString("idProducto");
                String nombreCategoria = res.getString("nombreCategoria");
                String nombre = res.getString("Nombre");
                String unidadCaja = res.getString("UnidadCaja");
                String precio = res.getString("Precio");
                
                data[increment][0] = idProducto;
                data[increment][1] = nombreCategoria;
                data[increment][2] = nombre;
                data[increment][3] = unidadCaja;
                data[increment][4] = precio;
                increment++;
            }
            res.close();
            closeConnection();
        } catch (SQLException e){
            System.out.println("Error: "+e);
        }
        
        return data;
    }
    
        public boolean save(Producto p){
        PreparedStatement saveProducto;
        
        try{
            saveProducto = this.getConnection().prepareStatement("INSERT INTO producto (idCategoria,Nombre,UnidadCaja,Precio)"
                            + "VALUES (?,?,?,?)");
            saveProducto.setInt(1, p.getIdCategoria());
            saveProducto.setString(2, p.getNombre());
            saveProducto.setInt(3, p.getUnidadCaja());
            saveProducto.setInt(4,p.getPrecio());
            
            saveProducto.executeUpdate(); //desde JDBC driver 5 solo las consultas se hacen con executeUpdate
            
            return true;
        } catch (SQLException e){
            System.out.println("Error: "+e);
            return false;
        } finally {
            closeConnection();
        }
    }
    
    /**
     * Este metodo actualiza una persona de la base de datos
     * @param persona
     */
    public boolean update(Producto p){
        PreparedStatement updateProducto;
        
        try{
            updateProducto = getConnection().prepareStatement("UPDATE persona SET idCategoria=?,Nombre=?, UnidadCaja=?, Precio=?"
                    + "WHERE idProducto=?");
            updateProducto.setInt(1,p.getIdCategoria());
            updateProducto.setString(2, p.getNombre());
            updateProducto.setInt(3, p.getUnidadCaja());
            updateProducto.setInt(4, p.getPrecio());
            updateProducto.setInt(5, p.getIdProducto());
            

            
            updateProducto.executeQuery();
            return true;
        } catch (SQLException e){
            System.out.println("Error: "+e);
            return false;
        } finally {
            closeConnection();
        }
    }
    
    public boolean delete(Producto p){
        PreparedStatement delete;
        
        try{
            if(Integer.toString(p.getIdProducto()) != null){
                delete = getConnection().prepareStatement("DELETE FROM producto WHERE idProducto = ?");
                
                delete.setInt(1, p.getIdProducto());
                
                delete.executeUpdate();
            }
            return true;
        } catch (SQLException e){
            System.out.println("Error = "+e);
            return false;
        }
    }
}
