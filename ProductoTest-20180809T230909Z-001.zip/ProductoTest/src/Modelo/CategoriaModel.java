
package Modelo;

import Utilidades.DBInstance;
import static Utilidades.DBInstance.closeConnection;
import Vista.Categoria;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author Nigger
 */

public class CategoriaModel{
       protected Connection getConnection(){
        return DBInstance.getInstanceConnection();
    }
        public Object [][] getCat(){
        int posId = 0;
        
        try {
            //ps position
            PreparedStatement pstm = getConnection().prepareStatement("SELECT count(1) as total FROM categoria");
            ResultSet res = pstm.executeQuery();
            
            res.next();
            posId = res.getInt("total");
            
        } catch (SQLException e){
            System.out.println("Error: "+e);
        }
        
        Object[][] data = new String[posId][5];
        
        try{
            PreparedStatement pstm = getConnection().prepareStatement("SELECT idCategoria, nombreCategoria FROM categoria\n");
            ResultSet res = pstm.executeQuery();
            
            int increment = 0;
            
            while(res.next()){
                String idCategoria = res.getString("idCategoria");
                String nombreCategoria = res.getString("nombreCategoria");
                
                data[increment][0] = idCategoria;
                data[increment][1] = nombreCategoria;
                increment++;
            }
            res.close();
            closeConnection();
        } catch (SQLException e){
            System.out.println("Error: "+e);
        }
        
        return data;
    }
    
        public boolean save(Categoria c){
        PreparedStatement saveCat;
        
        try{
            saveCat = this.getConnection().prepareStatement("INSERT INTO categoria (nombreCategoria)"
                            + "VALUES (?)");
            saveCat.setString(1, c.getNombreCategoria());
            
            saveCat.executeUpdate(); //desde JDBC driver 5 solo las consultas se hacen con executeUpdate
            
            return true;
        } catch (SQLException e){
            System.out.println("Error: "+e);
            return false;
        } finally {
            closeConnection();
        }
    }
    

    public boolean update(Categoria c){
        PreparedStatement updateCat;
        
        try{
            updateCat = getConnection().prepareStatement("UPDATE categoria SET nombreCategoria=?"
                    + "WHERE idCategoria=?");
            updateCat.setString(1, c.getNombreCategoria());
            updateCat.setInt(2,c.getIdCategoria());
    
            

            
            updateCat.executeUpdate();
            return true;
        } catch (SQLException e){
            System.out.println("Error: "+e);
            return false;
        } finally {
            closeConnection();
        }
    }
    
    public boolean delete(Categoria c){
        PreparedStatement deleteCat;
        
        try{
            if(Integer.toString(c.getIdCategoria()) != null){
                deleteCat = getConnection().prepareStatement("DELETE FROM categoria WHERE idCategoria = ?");
                
                deleteCat.setInt(1, c.getIdCategoria());
                
                deleteCat.executeUpdate();
                
            }
            return true;
        } catch (SQLException e){
            System.out.println("Error = "+e);
            return false;
        }
    }
}
