/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Conexion;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author cepardov
 */
public class DBInstance {
    private static Connection conn;
    private static final String baseDatos = "productos";
    private static final String usuario = "root";
    private static final String contraseña = "";
    private static final String port="3306";
    //com.mysql.jdbc.Driver
    private static final String driver="com.mysql.jdbc.Driver";
    private static final String url="jdbc:mysql://localhost:"+port+"/"+baseDatos;
    
    /**
     * Conexion a mysql
     * @return Un metodo para conectar a mysql
     */
    public static Connection getInstanceConnection(){
        if (!(conn instanceof Connection)) {
            System.out.println("Conectado a la Base de Datos.");
            try{
                Class.forName(driver);
                conn = DriverManager.getConnection(url, usuario, contraseña);
            } catch (ClassNotFoundException se){
                System.out.println("No se encontro la clase\n"+se);
            } catch (SQLException e){
                JOptionPane.showMessageDialog(null,"No se pudo establecer la conexión!\n"+e, "Error Grave", JOptionPane.ERROR_MESSAGE);
                System.out.println("Error: "+e);
            }
        }
        return conn;
    }
    
    public static void closeConnection(){
        try{
            if (conn instanceof Connection) {
                conn.close();
                conn = null;
                System.out.println("Se ha cerrado la conexión");
            }
        } catch (SQLException e){
            System.out.println("Error: "+e);
        }
    }
    
    public static boolean stateConnection(){
        return conn instanceof Connection;
    }
    
}

