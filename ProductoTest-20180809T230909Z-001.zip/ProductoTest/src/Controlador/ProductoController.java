/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import Utilidades.DBInstance;
import Modelo.ProductoModel;
import Vista.Producto;
import java.sql.Connection;
import java.util.ArrayList;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
/**
 *
 * @author Nigger
 */
public class ProductoController extends Producto{
    private ProductoModel pm = new ProductoModel();
    
    public Object[][] getProducto(){
        return pm.getProducto();
    }
    public boolean save(){
        return pm.save(this);
    }
    public boolean update(){
       return pm.update(this);
    }
    
    public boolean delete(){
       return pm.delete(this);
    }
}
