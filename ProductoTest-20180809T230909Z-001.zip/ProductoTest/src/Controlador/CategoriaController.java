/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import Modelo.CategoriaModel;
import Vista.Categoria;

/**
 *
 * @author Nigger
 */
public class CategoriaController extends Categoria{
        private CategoriaModel cm = new CategoriaModel();
    
    public Object[][] getCategoria(){
        return cm.getCat();
    }
    public boolean save(){
        return cm.save(this);
    }
    public boolean update(){
        return cm.update(this);
    }
    
    public boolean delete(){
        return cm.delete(this);
    }
}
